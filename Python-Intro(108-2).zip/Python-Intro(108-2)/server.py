
from flask import Flask, request, abort
from data import me, catalog
import json
import random
from flask_cors import CORS
from config import db
from bson import ObjectId

app = Flask(__name__)
CORS (app)



@app.get("/")
def home():
    return "Hello from flask"

@app.get("/test")
def test():
    return "This is just another endpoint"

# get /about resturns your name
@app.get("/about")
def about():
    return "Elizabeth Kim"

    #####################
    # API PRODUCTS
    ######################
def fix_id(obj):
    obj["_id"] = str(obj["_id"])
    return obj


@app.get("/api/test")
def test_api():
    return json.dumps("OK")

# get /api/about return the me dict as json

@app.get("/api/about")
def about_api():
    return json.dumps(me)


@app.get("/api/catalog")
def get_catalog():
    cursor = db.Products.find({}) # read all products
    results = []
    for prod in cursor:
        prod = fix_id(prod)
        results.append(prod)

        return json.dumps(results)




@app.post("/api/catalog")
def save_product():
    product = request.get_json()
    if not "title" in product:
        return abort(400, "ERROR: Title is required")

    if len(product["title"]) < 5:
        return abort(400, "ERROR: Title should have at least 5 chars")

    if not "price" in product:
        return abort(400, "ERROR: Price is required")

    if product["price"] <1:
            return abort(400, "Error: Price should be greater or equal to 1")

    #assigns a unique _id
    db.Products.insert_one(product)

    #fix _id
    product["_id"] = str(product["_id"])
    return json.dumps(product)

    

    





@app.get('/api/product/<id>')
def get_product_by_id(id):

    prod = db.Products.find_one({"_id": ObjectId(id)})
    if not prod:
        return abort(400,"Product not found")

    prod = fix_id(prod)
    return json.dumps(prod)



@app.get('/api/products/<category>')
def get_product_by_category(category):
    cursor = db.Products.find({"category": category})
    results = []
    for prod in cursor:
        prod = fix_id(prod)
        results.append(prod)

    return json.dumps(results)


@app.get("/api/count")
def catalog_count():
    cursor = db.Products.find({}) # def data from db into cursor
    products = []# move ever prod from cursor to a list
    for prod in cursor:# count the elements on the list 
        products.append(prod)
    count = len(catalog)
    return json.dumps(count)




@app.get("/api/catalog/total")
def catalog_total():
    total = 0
    cursor = db.Products.find({})
    for prod in cursor:
        total += prod["price"]

    return json.dumps(total)




@app.get("/api/catalog/cheapest")
def catalog_cheapest():
    cheapest = catalog[0]
    for prod in catalog:
        if prod["price"] < cheapest["price"]:
            #found a better fit
            cheapest = prod

    return json.dumps(cheapest)


@app.post("/api/coupons")
def save_coupon():
    coupon = request.get_json()
    if not "code" in coupon:
        abort(400, "code is required")
    
    if not "discount" in coupon:
        abort(400, "discount is required")

    db.CouponCodes.insert_one(coupon)
    coupon = fix_id(coupon)
    return json.dumps(coupon)

@app.get("/api/coupons")
def get_coupons():
    cursor = db.CouponCodes.find({})
    results = []
    for cp in cursor:
        cp = fix_id(cp)
        results.append(cp)

    return json.dumps(results)









@app.get("/api/game/<pick>")
def game(pick):
    num = random.randint(0,2)
    pc = ""
    if num == 0:
        pc = "paper"
    elif num ==1:
        pc = "rock"
    else:
        pc = "scissors"
    
    winner = ""
    if pick == "paper":
        if pc == "rock":
            winner = "your"
        elif pc =="scissors":
            winner = "pc"
        else:
            winner = "draw"

    elif pick == "rock":
        if pc == "rock":
            winner = "draw"
        elif pc == "scissors":
            winner = "you"
        else:
            winner = "pc"

    elif pick == "scissors":
        if pc == "rock":
            winner = "pc"
        elif pc == "scissors":
            winner = "draw"
        else:
            winner = "you"



    results = {
        "you" : pick,
        "pc": pc,
        "winner": winner
    }

    return json.dumps(results)





#app.run(debug=True)
