import pymongo
import certifi
con_str = "mongodb+srv://elikimq:1234554321@cluster0.mtkhjfk.mongodb.net/?retryWrites=true&w=majority"

client = pymongo.MongoClient(con_str, tlsCAFile=certifi.where())

db = client.get_database("Raw")