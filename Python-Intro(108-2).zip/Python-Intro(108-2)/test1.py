

from data import me
#get data from dict

print(me["first_name"] + " " + me["last_name"])

# modify
me ["color"] = "Gray"

# add
me ["age"] = 36

# read non existing key
# print(["title"]) # crash your code
# check if a key exist inside a dictionary
if "title" in me:
    print(me["title"])


# print the full address
address = me ["address"]
print (str(address["number"]) + " " + address["street"] + ", " + address["city"])
